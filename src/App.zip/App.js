import React, { useState, useEffect } from "react";
import axios from "axios";

function App() {

  // 🔹 Resource state
  const [resource, setResource] = useState({
    name: "",
    location: "",
    capacity: ""
  });

  // 🔹 Booking state (with date + time)
  const [booking, setBooking] = useState({
    resourceId: "",
    startDate: "",
    startTime: "",
    endDate: "",
    endTime: ""
  });

  // 🔹 Booking list
  const [bookings, setBookings] = useState([]);

  // ✅ Fetch bookings
  const fetchBookings = () => {
    axios.get("http://localhost:8081/booking/all")
      .then(res => setBookings(res.data))
      .catch(err => console.error(err));
  };

  useEffect(() => {
    fetchBookings();
  }, []);

  // ✅ Add Resource
  const handleAddResource = () => {
    axios.post("http://localhost:8081/booking/addResource", resource)
      .then(() => {
        alert("Resource added");
      })
      .catch(err => console.error(err));
  };

  // ✅ Create Booking (combine date + time)
  const handleCreateBooking = () => {

    const finalBooking = {
      resourceId: booking.resourceId,
      startTime: booking.startDate + "T" + booking.startTime,
      endTime: booking.endDate + "T" + booking.endTime
    };

    axios.post("http://localhost:8081/booking/create", finalBooking)
      .then(() => {
        alert("Booking created");
        fetchBookings(); // 🔥 refresh table
      })
      .catch(err => console.error(err));
  };

  return (
    <div style={{ padding: "20px" }}>

      <h2>Add Resource</h2>
      <input
        placeholder="Name"
        onChange={e => setResource({ ...resource, name: e.target.value })}
      />
      <input
        placeholder="Location"
        onChange={e => setResource({ ...resource, location: e.target.value })}
      />
      <input
        placeholder="Capacity"
        onChange={e => setResource({ ...resource, capacity: e.target.value })}
      />
      <button onClick={handleAddResource}>Add Resource</button>

      <hr />

      <h2>Create Booking</h2>

      <input
        placeholder="Resource ID"
        onChange={e => setBooking({ ...booking, resourceId: e.target.value })}
      />

      <br /><br />

      <label>Start Date: </label>
      <input
        type="date"
        onChange={e => setBooking({ ...booking, startDate: e.target.value })}
      />

      <label> Start Time: </label>
      <input
        type="time"
        onChange={e => setBooking({ ...booking, startTime: e.target.value })}
      />

      <br /><br />

      <label>End Date: </label>
      <input
        type="date"
        onChange={e => setBooking({ ...booking, endDate: e.target.value })}
      />

      <label> End Time: </label>
      <input
        type="time"
        onChange={e => setBooking({ ...booking, endTime: e.target.value })}
      />

      <br /><br />

      <button onClick={handleCreateBooking}>Create Booking</button>

      <hr />

      <h2>All Bookings</h2>

      <table border="1">
        <thead>
          <tr>
            <th>ID</th>
            <th>Resource ID</th>
            <th>Start Date</th>
            <th>Start Time</th>
            <th>End Date</th>
            <th>End Time</th>
            <th>Status</th>
          </tr>
        </thead>

        <tbody>
          {bookings.map((b, index) => (
            <tr key={index}>
              <td>{b.id}</td>
              <td>{b.resourceId}</td>
              <td>{b.startTime.split("T")[0]}</td>
              <td>{b.startTime.split("T")[1].substring(0,5)}</td>
              <td>{b.endTime.split("T")[0]}</td>
              <td>{b.endTime.split("T")[1].substring(0,5)}</td>
              <td>{b.status}</td>
            </tr>
          ))}
        </tbody>

      </table>

    </div>
  );
}

export default App;